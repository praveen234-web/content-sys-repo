
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { ContentProvider } from '@/contexts/ContentContext';
import MainLayout from '@/components/Layout/MainLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import LoginPage from '@/pages/Auth/LoginPage';
import SignupPage from '@/pages/Auth/SignupPage';
import DashboardPage from '@/pages/Dashboard/DashboardPage';
import PagesListPage from '@/pages/Content/PagesListPage';
import PageEditorPage from '@/pages/Content/PageEditorPage';
import MediaLibraryPage from '@/pages/Content/MediaLibraryPage';
import SchedulePage from '@/pages/Content/SchedulePage';
import UsersPage from '@/pages/Users/UsersPage';
import AnalyticsPage from '@/pages/Analytics/AnalyticsPage';
import SettingsPage from '@/pages/Settings/SettingsPage';
import NotFoundPage from '@/pages/NotFoundPage';
import { Toaster } from '@/components/ui/toaster';

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/signup" element={<SignupPage />} />
      
      <Route element={<ProtectedRoute />}>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Navigate to="/dashboard" />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="dashboard/pages" element={<PagesListPage />} />
          <Route path="dashboard/editor" element={<PageEditorPage />} />
          <Route path="dashboard/editor/:pageId" element={<PageEditorPage />} />
          <Route path="dashboard/media" element={<MediaLibraryPage />} />
          <Route path="dashboard/schedule" element={<SchedulePage />} />
          <Route path="dashboard/users" element={
            <ProtectedRoute allowedRoles={['Admin']}>
              <UsersPage />
            </ProtectedRoute>
          } />
          <Route path="dashboard/analytics" element={<AnalyticsPage />} />
          <Route path="dashboard/settings" element={<SettingsPage />} />
        </Route>
      </Route>
      
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ContentProvider>
          <Router>
            <AppRoutes />
            <Toaster />
          </Router>
        </ContentProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
