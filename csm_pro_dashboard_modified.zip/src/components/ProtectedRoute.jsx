
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';

const ProtectedRoute = ({ allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect to a 'not authorized' page or dashboard if role doesn't match
    // For now, redirecting to dashboard.
    // Consider creating a specific NotAuthorizedPage.jsx
    return <Navigate to="/dashboard" replace />; 
  }

  return <Outlet />;
};

export default ProtectedRoute;
