
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, FileText, Settings, LogOut, Users, BarChart3, Edit3, CalendarClock, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { motion } from 'framer-motion';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: Home },
  { to: '/dashboard/pages', label: 'Pages', icon: FileText },
  { to: '/dashboard/editor', label: 'Editor', icon: Edit3 },
  { to: '/dashboard/media', label: 'Media', icon: ImageIcon },
  { to: '/dashboard/schedule', label: 'Schedule', icon: CalendarClock },
  { to: '/dashboard/users', label: 'Users', icon: Users },
  { to: '/dashboard/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/dashboard/settings', label: 'Settings', icon: Settings },
];

const Sidebar = () => {
  const { logout } = useAuth();

  return (
    <motion.div 
      initial={{ x: -250 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
      className="w-64 bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100 p-6 flex flex-col h-full shadow-2xl"
    >
      <div className="mb-10">
        <NavLink to="/dashboard">
          <h1 className="text-3xl font-bold text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">CMS Pro</h1>
        </NavLink>
      </div>
      <nav className="flex-grow">
        <ul>
          {navItems.map((item) => (
            <li key={item.to} className="mb-2">
              <NavLink
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center p-3 rounded-lg transition-all duration-200 ease-in-out hover:bg-slate-700/50 ${
                    isActive ? 'bg-purple-600/70 text-white shadow-md' : 'hover:text-purple-300'
                  }`
                }
              >
                <item.icon className="mr-3 h-5 w-5" />
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <div>
        <Button
          variant="ghost"
          onClick={logout}
          className="w-full flex items-center justify-start p-3 text-slate-300 hover:bg-red-500/30 hover:text-red-100 transition-colors duration-200"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </Button>
      </div>
    </motion.div>
  );
};

export default Sidebar;
