
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Download, TrendingUp, Users, Clock, MousePointer } from 'lucide-react';
import { motion } from 'framer-motion';

const AnalyticsPage = () => {
  // Mock analytics data
  const pageViews = [
    { date: '2025-05-01', views: 1200 },
    { date: '2025-05-02', views: 1800 },
    { date: '2025-05-03', views: 1600 },
    { date: '2025-05-04', views: 2200 },
    { date: '2025-05-05', views: 2400 },
    { date: '2025-05-06', views: 2100 },
    { date: '2025-05-07', views: 2800 },
  ];

  const stats = [
    { title: 'Total Views', value: '15.2K', icon: TrendingUp, change: '+12.3%' },
    { title: 'Unique Visitors', value: '8.4K', icon: Users, change: '+8.1%' },
    { title: 'Avg. Time', value: '4:23', icon: Clock, change: '+2.5%' },
    { title: 'Bounce Rate', value: '24.8%', icon: MousePointer, change: '-3.2%' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Analytics</h1>
          <p className="text-muted-foreground">Track your website performance</p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <stat.icon className="h-8 w-8 text-primary" />
                  <span className={`text-sm font-medium ${
                    stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <h2 className="text-2xl font-bold mt-2">{stat.value}</h2>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Page Views</CardTitle>
          <CardDescription>Last 7 days traffic</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={pageViews}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(date) => new Date(date).toLocaleDateString()}
                />
                <YAxis />
                <Tooltip
                  labelFormatter={(date) => new Date(date).toLocaleDateString()}
                  formatter={(value) => [`${value} views`, 'Page Views']}
                />
                <Line
                  type="monotone"
                  dataKey="views"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Top Pages</CardTitle>
            <CardDescription>Most viewed pages</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { title: 'Homepage', views: '3.2K', change: '+12%' },
                { title: 'About Us', views: '2.4K', change: '+8%' },
                { title: 'Products', views: '1.8K', change: '+15%' },
              ].map((page, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{page.title}</p>
                    <p className="text-sm text-muted-foreground">{page.views} views</p>
                  </div>
                  <span className="text-green-600 text-sm">{page.change}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Traffic Sources</CardTitle>
            <CardDescription>Where your visitors come from</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { source: 'Direct', percentage: '45%', value: '6.8K' },
                { source: 'Search', percentage: '32%', value: '4.9K' },
                { source: 'Social', percentage: '23%', value: '3.5K' },
              ].map((source, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{source.source}</p>
                    <p className="text-sm text-muted-foreground">{source.value}</p>
                  </div>
                  <div className="h-2 bg-muted rounded-full">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{ width: source.percentage }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AnalyticsPage;
