
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle, Edit, Trash2, Eye, Clock } from 'lucide-react';
import { useContent } from '@/contexts/ContentContext';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const PagesListPage = () => {
  const { pages, drafts, deletePage } = useContent();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const PageCard = ({ page, isDraft }) => (
    <motion.div variants={item}>
      <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardContent className="flex items-center justify-between p-6">
          <div className="flex-1">
            <h3 className="text-lg font-semibold">{page.title || 'Untitled Page'}</h3>
            <p className="text-sm text-muted-foreground">
              {isDraft ? 'Draft' : 'Published'} • Last modified: {new Date(page.createdAt).toLocaleDateString()}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" asChild>
              <Link to={`/dashboard/editor/${page.id}`}>
                <Edit className="h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="icon">
              <Eye className="h-4 w-4" />
            </Button>
            <Button variant="destructive" size="icon" onClick={() => deletePage(page.id)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Pages</h1>
          <p className="text-muted-foreground">Manage your website content</p>
        </div>
        <Button asChild>
          <Link to="/dashboard/editor" className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4" />
            Create New Page
          </Link>
        </Button>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              Drafts ({drafts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-4"
            >
              {drafts.map(draft => (
                <PageCard key={draft.id} page={draft} isDraft={true} />
              ))}
              {drafts.length === 0 && (
                <p className="text-muted-foreground text-center py-4">No drafts yet</p>
              )}
            </motion.div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-green-500" />
              Published ({pages.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-4"
            >
              {pages.map(page => (
                <PageCard key={page.id} page={page} isDraft={false} />
              ))}
              {pages.length === 0 && (
                <p className="text-muted-foreground text-center py-4">No published pages yet</p>
              )}
            </motion.div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PagesListPage;
