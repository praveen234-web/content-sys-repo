
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, Edit } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const SchedulePage = () => {
  // Mock scheduled content
  const scheduledContent = [
    {
      id: 1,
      title: "Summer Collection Launch",
      scheduledFor: "2025-06-01T09:00:00",
      author: "John Doe",
      status: "scheduled"
    },
    {
      id: 2,
      title: "Back to School Campaign",
      scheduledFor: "2025-08-15T10:00:00",
      author: "Jane Smith",
      status: "scheduled"
    }
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Content Schedule</h1>
          <p className="text-muted-foreground">Manage your scheduled content</p>
        </div>
        <Button asChild>
          <Link to="/dashboard/editor">
            Schedule New Content
          </Link>
        </Button>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Upcoming Publications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              {scheduledContent.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{item.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        {new Date(item.scheduledFor).toLocaleString()}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        By {item.author}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" asChild>
                        <Link to={`/dashboard/editor/${item.id}`}>
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Link>
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
              {scheduledContent.length === 0 && (
                <p className="text-center text-muted-foreground py-8">
                  No scheduled content yet
                </p>
              )}
            </motion.div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SchedulePage;
