
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useContent } from '@/contexts/ContentContext';
import { Save, Eye, Clock, Send } from 'lucide-react';
import { motion } from 'framer-motion';

const PageEditorPage = () => {
  const { pageId } = useParams();
  const navigate = useNavigate();
  const { createPage, updatePage, drafts, pages } = useContent();
  
  const [content, setContent] = useState({
    title: '',
    content: '',
    slug: '',
    metaTitle: '',
    metaDescription: '',
  });

  useEffect(() => {
    if (pageId) {
      const page = [...pages, ...drafts].find(p => p.id === pageId);
      if (page) {
        setContent({
          title: page.title || '',
          content: page.content || '',
          slug: page.slug || '',
          metaTitle: page.metaTitle || '',
          metaDescription: page.metaDescription || '',
        });
      }
    }
  }, [pageId, pages, drafts]);

  const handleSave = () => {
    if (pageId) {
      updatePage(pageId, content);
    } else {
      const newPage = createPage(content);
      navigate(`/dashboard/editor/${newPage.id}`);
    }
  };

  return (
    <div className="h-[calc(100vh-theme(spacing.16))] flex gap-4">
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex-1 flex flex-col gap-4"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">
              {pageId ? 'Edit Page' : 'Create New Page'}
            </h1>
            <p className="text-muted-foreground">
              {pageId ? 'Make changes to your page' : 'Create a new page for your website'}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Clock className="h-4 w-4 mr-2" />
              Auto-saved
            </Button>
            <Button variant="outline">
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </Button>
            <Button onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
            <Button variant="secondary">
              <Send className="h-4 w-4 mr-2" />
              Publish
            </Button>
          </div>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Page Title</Label>
              <Input
                id="title"
                value={content.title}
                onChange={(e) => setContent(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter page title"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Content</Label>
              <textarea
                id="content"
                value={content.content}
                onChange={(e) => setContent(prev => ({ ...prev, content: e.target.value }))}
                className="w-full h-[400px] p-3 rounded-md border"
                placeholder="Start writing your content..."
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-80 space-y-4"
      >
        <Card>
          <CardContent className="p-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="slug">URL Slug</Label>
              <Input
                id="slug"
                value={content.slug}
                onChange={(e) => setContent(prev => ({ ...prev, slug: e.target.value }))}
                placeholder="page-url-slug"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="metaTitle">Meta Title</Label>
              <Input
                id="metaTitle"
                value={content.metaTitle}
                onChange={(e) => setContent(prev => ({ ...prev, metaTitle: e.target.value }))}
                placeholder="Meta title for SEO"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="metaDescription">Meta Description</Label>
              <textarea
                id="metaDescription"
                value={content.metaDescription}
                onChange={(e) => setContent(prev => ({ ...prev, metaDescription: e.target.value }))}
                className="w-full h-24 p-3 rounded-md border"
                placeholder="Meta description for SEO"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default PageEditorPage;
