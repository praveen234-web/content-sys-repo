package klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FspApplication {

	public static void main(String[] args) {
		SpringApplication.run(FspApplication.class, args);
	}

}
