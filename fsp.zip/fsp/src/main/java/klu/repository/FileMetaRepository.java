package klu.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import klu.model.*;

@Repository
public interface FileMetaRepository extends JpaRepository<FIleMeta, Long> {
    Optional<FIleMeta> findByShareToken(String shareToken);
}